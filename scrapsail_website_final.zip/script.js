
document.addEventListener('DOMContentLoaded', () => {
  console.log("ScrapSail site loaded.");
});
